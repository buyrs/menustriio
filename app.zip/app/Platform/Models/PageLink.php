<?php

namespace Platform\Models;

use Illuminate\Database\Eloquent\Model;
use Platform\Controllers\Core;
use Spatie\Image\Manipulations;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Spatie\MediaLibrary\Models\Media;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;

class PageLink extends Model implements HasMedia
{
    use HasMediaTrait;

    protected $table = 'page_links';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
    ];

    /**
     * Appended columns.
     *
     * @var array
     */
    protected $appends = [
      'image'
    ];

    public function registerMediaCollections() {

      $this
        ->addMediaCollection('image')
        ->singleFile();
    }

    public function registerMediaConversions(Media $media = null) {
        $this
          ->addMediaConversion('square')
          ->width(512)
          ->height(512)
          ->performOnCollections('image');
    }

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [];

    /**
     * Field mutators.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * Date/time fields that can be used with Carbon.
     *
     * @return array
     */
    public function getDates() {
      return ['created_at', 'updated_at'];
    }

    public static function boot() {
      parent::boot();

      // On update
      static::updating(function ($model) {
        if (auth()->check()) {
          $model->updated_by = auth()->user()->id;
        }
      });

      // On create
      self::creating(function ($model) {
        // Generate and set UUID
        $uuid = Str::orderedUuid();
        $model->uuid = (string) $uuid;

        if (auth()->check()) {
          $model->created_by = auth()->user()->id;
        }

        // Order
        $last = PageLink::where('created_by', $model->created_by)->max('order');
        $order = ($last !== null) ? $last + 1 : 1;
        $model->order = $order;
      });
    }

    /**
     * Images
     * -------------
     */

    public function getImageAttribute() {
      return ($this->getFirstMediaUrl('image') !== '') ? $this->getMedia('image')[0]->getUrl('square') : null;
    }

    /**
     * Relationships
     * -------------
     */

    public function user() {
      return $this->belongsTo(\App\User::class, 'created_by', 'id');
    }
}