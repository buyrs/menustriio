<?php

namespace Platform\Controllers\Pages;

use App\User;
use App\Http\Controllers;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

use Platform\Models\PageLink;

class PageController extends \App\Http\Controllers\Controller
{
  /*
  |--------------------------------------------------------------------------
  | Page Controller
  |--------------------------------------------------------------------------
  */

  /**
   * Get user page.
   *
   * @return \Symfony\Component\HttpFoundation\Response 
   */
  public function getPage(Request $request) {
    $slug = $request->slug;
    if ($slug !== null) {
      $user = User::where('slug', $slug)->where('active', 1)->first();
      if ($user !== null) {

        // Track page
        $cookie = \Platform\Controllers\Analytics\TrackingController::track(
          $identifier = $user->id,
          $type = 'visit',
          $created_by = $user->id,
          $timeZone = $user->getTimezone()
        );

        $response = $user->getPage();

        if ($cookie !== null) {
          return response()->json($response, 200)->withCookie($cookie);
        } else {
          return response()->json($response, 200);
        }
      }
    }
    return response()->json(['status' => '404'], 404);
  }

  /**
   * Click link.
   *
   * @return \Symfony\Component\HttpFoundation\Redirect 
   */
  public function getClick($uuid) {
    $pageLink = PageLink::where('uuid', $uuid)->first();
    if ($pageLink !== null) {
        // Track click
        $cookie = \Platform\Controllers\Analytics\TrackingController::track(
          $identifier = $pageLink->id,
          $type = 'click',
          $created_by = $pageLink->user->id,
          $timeZone = $pageLink->user->getTimezone()
      );

      if ($cookie !== null) {
        return redirect($pageLink->url)->withCookie($cookie);
      } else {
        return redirect($pageLink->url);
      }
    } else {
      return redirect('/');
    }
  }

  /**
   * Get user page links.
   *
   * @return \Symfony\Component\HttpFoundation\Response 
   */
  public function getUserPageLinks(Request $request) {
    $uuid = $request->uuid;
    if ($uuid == null) {
      $user = auth()->user();
    } else {
      $user = \App\User::whereUuid($uuid)->first();
    }

    $response = $user->getPageLinks();
    return response()->json($response, 200);
  }

  /**
   * Update slug.
   *
   * @return \Symfony\Component\HttpFoundation\Response 
   */
  public function postSavePageUrl(Request $request) {
    $locale = request('locale', config('default.language'));
    app()->setLocale($locale);

    if (env('APP_DEMO', false) === true && (auth()->user()->id == 1 || auth()->user()->id == 2)) {
      return response()->json(['status' => 'error', 'msg' => "This is a demo user. You can't update or delete anything in this account. If you want to test all user features, sign up with a new account."], 422);
    }

    $r = $request->form;

    $v = Validator::make($r, [
      'slug' => ['required', 'min:5', 'max:32', Rule::unique('users')->where(function ($query) {
          return $query->where('id', '<>', auth()->user()->id);
        })
      ]
    ]);

    if ($v->fails()) {
      return response()->json([
        'status' => 'error',
        'errors' => $v->errors()
      ], 422);
    }

    auth()->user()->slug = $r['slug'];
    auth()->user()->save();

    return response()->json(['status' => 'success', 'msg' => trans('app.update_success')], 200);
  }

  /**
   * Create / update page.
   *
   * @return \Symfony\Component\HttpFoundation\Response 
   */
  public function postSavePageLink(Request $request) {
    $locale = request('locale', config('default.language'));
    app()->setLocale($locale);

    if (env('APP_DEMO', false) === true && (auth()->user()->id == 1 || auth()->user()->id == 2)) {
      return response()->json(['status' => 'error', 'msg' => "This is a demo user. You can't update or delete anything in this account. If you want to test all user features, sign up with a new account."], 422);
    }

    $r = $request->form;

    // Check max links
    if ($r['uuid'] == '') {
      $pageLinkCount = auth()->user()->pageLinks->count();
      $maxPageLinks = auth()->user()->plan_limitations['links'];
      if ($pageLinkCount >= $maxPageLinks) {
        return response()->json(['status' => 'error', 'msg' => trans('app.max_amount_of_links_reached')], 422);
      }
    }

    $v = Validator::make($r, [
      'title' => 'required|max:48',
      'color' => 'required|min:7|max:7',
      'description' => 'nullable|max:300',
      'url' => 'required|url',
    ]);

    if ($v->fails()) {
      return response()->json([
        'status' => 'error',
        'errors' => $v->errors()
      ], 422);
    }

    if ($r['uuid'] == '') {
      $pageLink = new PageLink;
      $msg = trans('app.link_created');
    } else {
      $pageLink = PageLink::whereUuid($r['uuid'])->where('created_by', auth()->user()->id)->first();
      $msg = trans('app.link_updated_successfully');
    }

    if ($pageLink !== null) {
      $pageLink->title = $r['title'];
      $pageLink->color = $r['color'];
      $pageLink->description = $r['description'];
      $pageLink->url = $r['url'];
      $pageLink->save();
    }

    return response()->json(['status' => 'success', 'msg' => $msg], 200);
  }

  /**
   * Move link up or down.
   *
   * @return \Symfony\Component\HttpFoundation\Response 
   */
  public function postChangePageLinkOrder(Request $request) {
    $locale = request('locale', config('default.language'));
    app()->setLocale($locale);

    if (env('APP_DEMO', false) === true && (auth()->user()->id == 1 || auth()->user()->id == 2)) {
      return response()->json(['status' => 'error', 'msg' => "This is a demo user. You can't update or delete anything in this account. If you want to test all user features, sign up with a new account."], 422);
    }

    $uuid1 = $request->uuid1;
    $uuid2 = $request->uuid2;

    $pageLinkFrom = PageLink::whereUuid($uuid1)->where('created_by', auth()->user()->id)->first();
    $pageLinkTo = PageLink::whereUuid($uuid2)->where('created_by', auth()->user()->id)->first();

    if ($pageLinkFrom !== null && $pageLinkTo !== null) {
      $orderFrom = $pageLinkFrom->order;
      $orderTo = $pageLinkTo->order;

      $pageLinkFrom->order = $orderTo;
      $pageLinkFrom->save();

      $pageLinkTo->order = $orderFrom;
      $pageLinkTo->save();
    }

    return response()->json(['status' => 'success', 'msg' => trans('app.link_moved_successfully')], 200);
  }

  /**
   * Delete page link.
   *
   * @return \Symfony\Component\HttpFoundation\Response 
   */
  public function postDeletePageLink(Request $request) {
    $locale = request('locale', config('default.language'));
    app()->setLocale($locale);

    if (env('APP_DEMO', false) === true && (auth()->user()->id == 1 || auth()->user()->id == 2)) {
      return response()->json(['status' => 'error', 'msg' => "This is a demo user. You can't update or delete anything in this account. If you want to test all user features, sign up with a new account."], 422);
    }

    $uuid = $request->uuid;

    $pageLink = PageLink::whereUuid($uuid)->where('created_by', auth()->user()->id)->first();

    if ($pageLink !== null) {
      $pageLink->delete();
    }

    return response()->json(['status' => 'success', 'msg' => trans('app.link_deleted_successfully')], 200);
  }
}
