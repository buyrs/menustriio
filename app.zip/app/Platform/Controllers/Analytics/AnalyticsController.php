<?php

namespace Platform\Controllers\Analytics;

use App\User;
use App\Http\Controllers;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AnalyticsController extends \App\Http\Controllers\Controller
{
  /*
  |--------------------------------------------------------------------------
  | Analytics Controller
  |--------------------------------------------------------------------------
  */

  /**
   * Get daily analytics.
   *
   * @return \Symfony\Component\HttpFoundation\Response 
   */
  public function getAnalytics() {
    $period = request('period', 'week');

    $timeZone = auth()->user()->getTimezone();
    $created_by = auth()->user()->id;

    $today = Carbon::now($timeZone)->toDateString();
    $hour = Carbon::now($timeZone)->hour;
    $weekOfYear = Carbon::now($timeZone)->weekOfYear;
    $month = Carbon::now($timeZone)->month;
    $year = Carbon::now($timeZone)->year;
    $startOfWeek = Carbon::now($timeZone)->startOfWeek()->toDateString();
    $endOfWeek = Carbon::now($timeZone)->endOfWeek()->toDateString();
    $startOfMonth = Carbon::now($timeZone)->startOfMonth()->toDateString();
    $endOfMonth = Carbon::now($timeZone)->endOfMonth()->toDateString();
    $startOfYear = Carbon::now($timeZone)->startOfYear()->toDateString();
    $endOfYear = Carbon::now($timeZone)->endOfYear()->toDateString();

    /**
     * Hourly count
     */

    $pageViews = 0;
    $pageClicks = 0;

    $identifier = '';
    $type = '';

    if ($period == 'today') {
      $range = array_fill(0, 24, 0);

      /**
       * Views
       */
      $data = DB::table('analytics_track_hourly')
        ->select([
          DB::raw('hour'),
          DB::raw('count as `count`')
        ])
        ->where('type', 'visit')
        ->where('created_at', $today)
        ->where('created_by', $created_by)
        ->groupBy('hour')
        ->groupBy('count')
        ->get()
        ->pluck('count', 'hour');

      $total = 0;
      if ($data !== null) {
        foreach($data as $hour => $count) {
          $range[$hour] = (int) $count;
          $total += $count;
        }
      }
      $pageViews = $total;

      $viewsLabels = [];
      $viewsValues = [];
      foreach ($range as $hour => $count) {
        $viewsLabels[] = $hour;
        $viewsValues[] = $count;
      }

      /**
       * Clicks
       */
      $pageClicks = DB::table('analytics_track_daily')
        ->where('type', 'click')
        ->where('created_at', $today)
        ->where('created_by', $created_by)
        ->sum('count');

    } elseif ($period == 'week') {
      $dFrom = $startOfWeek;
      $dTo = $endOfWeek;

      $period = new \DatePeriod( new \DateTime($dFrom), new \DateInterval('P1D'), new \DateTime($dTo));

      /**
       * Views
       */
      $range = [];
      foreach($period as $date){
        $range[$date->format("Y-m-d")] = 0;
      }

      $data = DB::table('analytics_track_daily')
        ->select([
          DB::raw('DATE(`created_at`) as `date`'),
          DB::raw('count as `count`')
        ])
        ->where('type', 'visit')
        ->whereBetween('created_at', [$dFrom, $dTo])
        ->where('created_by', $created_by)
        ->groupBy('date')
        ->groupBy('count')
        ->get()
        ->pluck('count', 'date');

      $total = 0;
      if ($data !== null) {
        foreach($data as $date => $count) {
          $range[$date] = (int) $count;
          $total += $count;
        }
      }
      $pageViews = $total;

      $viewsLabels = [];
      $viewsValues = [];
      foreach ($range as $date => $count) {
        $viewsLabels[] = Carbon::parse($date)->format("j");
        $viewsValues[] = $count;
      }

      /**
       * Clicks
       */
      $pageClicks = DB::table('analytics_track_daily')
        ->where('type', 'click')
        ->whereBetween('created_at', [$dFrom, $dTo])
        ->where('created_by', $created_by)
        ->sum('count');

    } elseif ($period == 'month') {
      $dFrom = $startOfMonth;
      $dTo = $endOfMonth;

      $period = new \DatePeriod( new \DateTime($dFrom), new \DateInterval('P1D'), new \DateTime($dTo));

      /**
       * Views
       */
      $range = [];
      foreach($period as $date){
        $range[$date->format("Y-m-d")] = 0;
      }

      $data = DB::table('analytics_track_daily')
        ->select([
          DB::raw('DATE(`created_at`) as `date`'),
          DB::raw('count as `count`')
        ])
        ->where('type', 'visit')
        ->whereBetween('created_at', [$dFrom, $dTo])
        ->where('created_by', $created_by)
        ->groupBy('date')
        ->groupBy('count')
        ->get()
        ->pluck('count', 'date');

      $total = 0;
      if ($data !== null) {
        foreach($data as $date => $count) {
          $range[$date] = (int) $count;
          $total += $count;
        }
      }
      $pageViews = $total;

      $viewsLabels = [];
      $viewsValues = [];
      foreach ($range as $date => $count) {
        $viewsLabels[] = Carbon::parse($date)->format("j");
        $viewsValues[] = $count;
      }

      /**
       * Clicks
       */
      $pageClicks = DB::table('analytics_track_daily')
        ->where('type', 'click')
        ->whereBetween('created_at', [$dFrom, $dTo])
        ->where('created_by', $created_by)
        ->sum('count');

    } elseif ($period == 'all_time') {

      /**
       * Views
       */
      $pageViews = DB::table('analytics_track_all_time')
      ->where('type', 'visit')
      ->where('created_by', $created_by)
      ->sum('count');

      $viewsLabels = [];
      $viewsValues = [];

      /**
       * Clicks
       */
      $pageClicks = DB::table('analytics_track_all_time')
        ->where('type', 'click')
        ->where('created_by', $created_by)
        ->sum('count');
    }

    $response = [
      'pageViews' => $pageViews,
      'viewsLabels' => $viewsLabels,
      'viewsValues' => $viewsValues,
      'pageClicks' => $pageClicks
    ];

    return response()->json($response, 200);
  }
}