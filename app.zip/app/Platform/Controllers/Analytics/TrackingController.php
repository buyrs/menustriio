<?php

namespace Platform\Controllers\Analytics;

use App\User;
use App\Http\Controllers;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TrackingController extends \App\Http\Controllers\Controller
{
    /*
    |--------------------------------------------------------------------------
    | Tracking Controller
    |--------------------------------------------------------------------------
    */

    /**
     * Track identifier, increment counter.
     *
     * @return \Symfony\Component\HttpFoundation\Response 
     */
    public static function track($identifier = null, $type = 'visit', $created_by = 0, $timeZone = 'UTC', $date = null) {
        if ($identifier === null) {
            $url_parts = parse_url(request()->url());
            $identifier = $url_parts['host'] . $url_parts['path'];
        }

        $cookiePath = '/';
/*
        if ($cookiePath === null) {
            $url_parts = parse_url(request()->url());
            $cookiePath = $url_parts['path'];
        }
*/
        // Check if cookie exists
        switch ($type) {
            case 'visit': $cookieName = '_v_' . Str::slug($identifier); break;
            case 'click': $cookieName = '_c_' . Str::slug($identifier); break;
            default: $cookieName = null;
        }

        $track = ($cookieName !== null) ? (bool) Cookie::get($cookieName, true) : true;
        $cookie = null;

        if (! $track) {
            // Track nothing
        } else {
            // Set date
            $date = ($date == null) ? Carbon::now($timeZone) : Carbon::createFromFormat('Y-m-d H:i:s', $date, $timeZone);

            // Add cookie that expires end of day
            if ($cookieName !== null) {
                $minutesUntilEndOfDay = $date->diffInMinutes(Carbon::now()->endOfDay());
                //Cookie::queue($cookieName, '0', $minutesUntilEndOfDay, $cookiePath);
                $cookie = cookie($cookieName, '0', $minutesUntilEndOfDay, $cookiePath);
            }

            /**
             * Insert or update count
             */
            $today = $date->toDateString();
            $hour = $date->hour;
            $weekOfYear = $date->weekOfYear;
            $month = $date->month;
            $year = $date->year;
            $startOfWeek = $date->startOfWeek()->toDateString();
            $endOfWeek = $date->endOfWeek()->toDateString();
            $startOfMonth = $date->startOfMonth()->toDateString();
            $endOfMonth = $date->endOfMonth()->toDateString();
            $startOfYear = $date->startOfYear()->toDateString();
            $endOfYear = $date->endOfYear()->toDateString();

            /**
             * Hourly count
             */

             // Get count
            $get = DB::table('analytics_track_hourly')
                ->select('count')
                ->where('type', $type)
                ->where('identifier', $identifier)
                ->where('hour', $hour)
                ->where('created_at', $today)
                ->first();

            $insert = empty($get) ? true : false;
            $count = empty($get) ? 0 : $get->count;

            // Insert or update
            if ($insert) {
                DB::table('analytics_track_hourly')->insert([
                    'type' => $type,
                    'identifier' => $identifier,
                    'count' => $count + 1,
                    'hour' => $hour,
                    'created_at' => $today,
                    'created_by' => $created_by
                ]);
            } else {
                DB::table('analytics_track_hourly')
                    ->where('type', $type)
                    ->where('identifier', $identifier)
                    ->where('hour', $hour)
                    ->where('created_at', $today)
                    ->update([
                        'count' => $count + 1
                    ]);
            }

            /**
             * Daily count
             */

             // Get count
            $get = DB::table('analytics_track_daily')
                ->select('count')
                ->where('type', $type)
                ->where('identifier', $identifier)
                ->where('created_at', $today)
                ->first();

            $insert = empty($get) ? true : false;
            $count = empty($get) ? 0 : $get->count;

            // Insert or update
            if ($insert) {
                DB::table('analytics_track_daily')->insert([
                    'type' => $type,
                    'identifier' => $identifier,
                    'count' => $count + 1,
                    'created_at' => $today,
                    'created_by' => $created_by
                ]);
            } else {
                DB::table('analytics_track_daily')
                    ->where('type', $type)
                    ->where('identifier', $identifier)
                    ->where('created_at', $today)
                    ->update([
                        'count' => $count + 1
                    ]);
            }

            /**
             * Weekly count
             */

             // Get count
            $get = DB::table('analytics_track_weekly')
                ->select('count')
                ->where('type', $type)
                ->where('identifier', $identifier)
                ->where('week_of_year', $weekOfYear)
                ->where('year', $year)
                ->first();

            $insert = empty($get) ? true : false;
            $count = empty($get) ? 0 : $get->count;

            // Insert or update
            if ($insert) {
                DB::table('analytics_track_weekly')->insert([
                    'type' => $type,
                    'identifier' => $identifier,
                    'count' => $count + 1,
                    'week_of_year' => $weekOfYear,
                    'year' => $year,
                    'start_at' => $startOfWeek,
                    'end_at' => $endOfWeek,
                    'created_by' => $created_by
                ]);
            } else {
                DB::table('analytics_track_weekly')
                    ->where('type', $type)
                    ->where('identifier', $identifier)
                    ->where('week_of_year', $weekOfYear)
                    ->where('year', $year)
                    ->update([
                        'count' => $count + 1
                    ]);
            }

            /**
             * Monthly count
             */

             // Get count
            $get = DB::table('analytics_track_monthly')
                ->select('count')
                ->where('type', $type)
                ->where('identifier', $identifier)
                ->where('month', $month)
                ->where('year', $year)
                ->first();

            $insert = empty($get) ? true : false;
            $count = empty($get) ? 0 : $get->count;

            // Insert or update
            if ($insert) {
                DB::table('analytics_track_monthly')->insert([
                    'type' => $type,
                    'identifier' => $identifier,
                    'count' => $count + 1,
                    'month' => $month,
                    'year' => $year,
                    'start_at' => $startOfMonth,
                    'end_at' => $endOfMonth,
                    'created_by' => $created_by
                ]);
            } else {
                DB::table('analytics_track_monthly')
                    ->where('type', $type)
                    ->where('identifier', $identifier)
                    ->where('month', $month)
                    ->where('year', $year)
                    ->update([
                        'count' => $count + 1
                    ]);
            }

            /**
             * Yearly count
             */

             // Get count
            $get = DB::table('analytics_track_yearly')
                ->select('count')
                ->where('type', $type)
                ->where('identifier', $identifier)
                ->where('year', $year)
                ->first();

            $insert = empty($get) ? true : false;
            $count = empty($get) ? 0 : $get->count;

            // Insert or update
            if ($insert) {
                DB::table('analytics_track_yearly')->insert([
                    'type' => $type,
                    'identifier' => $identifier,
                    'count' => $count + 1,
                    'year' => $year,
                    'start_at' => $startOfYear,
                    'end_at' => $endOfYear,
                    'created_by' => $created_by
                ]);
            } else {
                DB::table('analytics_track_yearly')
                    ->where('type', $type)
                    ->where('identifier', $identifier)
                    ->where('year', $year)
                    ->update([
                        'count' => $count + 1
                    ]);
            }

            /**
             * All time count
             */

             // Get count
            $get = DB::table('analytics_track_all_time')
                ->select('count')
                ->where('type', $type)
                ->where('identifier', $identifier)
                ->first();

            $insert = empty($get) ? true : false;
            $count = empty($get) ? 0 : $get->count;

            // Insert or update
            if ($insert) {
                DB::table('analytics_track_all_time')->insert([
                    'type' => $type,
                    'identifier' => $identifier,
                    'count' => $count + 1,
                    'created_by' => $created_by
                ]);
            } else {
                DB::table('analytics_track_all_time')
                    ->where('identifier', $identifier)
                    ->update([
                        'count' => $count + 1
                    ]);
            }

        }
        return $cookie;
    }
}